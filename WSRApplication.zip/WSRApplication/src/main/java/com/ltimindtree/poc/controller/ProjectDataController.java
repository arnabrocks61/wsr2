package com.ltimindtree.poc.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.poc.entity.ProjectData;
import com.ltimindtree.poc.service.ProjectDataService;



@RestController
@RequestMapping("/api/projectdata")
public class ProjectDataController {
	
	@Autowired
	private ProjectDataService projectService;
	
	@GetMapping
	public ResponseEntity<?> findAll() {
		
		List<ProjectData> prods = projectService.findAll();

		
		return ResponseEntity.ok().body(prods);
	}
/*
	@PostMapping()
	public ResponseEntity<ProjectData> createProduct(@RequestBody ProjectData projects) {
		return ResponseEntity.ok().body(projectService.createProduct(projects));
	}
	
	@PutMapping()
	public ResponseEntity<List<ProjectData>> updateProduct(@RequestBody List<ProjectData> projectlist) {
		return ResponseEntity.ok().body(projectService.updateBulkProduct(projectlist));
	}
	
	@DeleteMapping()
	public HttpStatus deleteProduct(@PathVariable long id) {
		projectService.deleteById(id);
		
		return HttpStatus.OK;
	}
*/
}
